# Content Requirements for Student Home Page
## 1. Create a heading for the page >> CISW327 Online 2nd 8wk - Spring 2020 - Your first name and last initial
## 2. Create a heading >> Introduction - write a short introduction (5-10 sentences)
## 3. Create a heading >> Education Plans - write a short summary for your plans (5-10 sentences)
## 4. Create a heading >> Assignments - provide links to each chapter of all assignments, for example: Include at least one image (and use attributes: alt, height, width)
## 5. Create a wrapper using an ID, which holds all content in <body>
## 6. Create a CSS external stylesheet to format the wrapper
## 7. Use a CSS style for a background for the page (in the external style sheet)

 
 
 ## 8. Pacific Trails Resort - Case Study #1 ( HEADING)
ch2 (RELATIVE links to home page for chapter 2)
ch3 (RELATIVE links to home page for chapter 3)
ch4 (RELATIVE links to home page for chapter 4)

## 9. Path of Light Yoga - Case Study #2 (HEADING)

ch2 (RELATIVE links to home page for chapter 2)
ch3 (RELATIVE links to home page for chapter 3)
ch4 (RELATIVE links to home page for chapter 4)